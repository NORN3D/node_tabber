# Node Tabber 0.4.0

Blender 5.2 compatibility update. Press **Tab** in a node editor to search for
nodes, their operations, and local node groups. **Ctrl+Tab** edits a node group.

## Install

In Blender, open **Edit > Preferences > Add-ons**, choose **Install from Disk**
from the menu, select `NodeTabber-0.4.0-Blender5.2.zip`, and enable **Node Tabber**.
Disable an older installed copy first to avoid duplicate Tab bindings.

## Compatibility

The 5.2 catalogs were generated and tested with Blender **5.2.3 LTS**
(`e13b728c6880`). They cover every creatable built-in node type in Geometry,
Shader, Compositor, and legacy Texture node trees. Simulation, Repeat,
For Each Geometry Element, and Closure entries create paired zone endpoints.
Node groups have separate entries with recursive groups excluded.

The catalogs preserve context filters for shader engines, world/object/line-style
shaders, and geometry node tools. They add new 5.2 nodes, including the XPBD
Solver, mesh bevel, list operations, and compositor additions. RNA enum values
that are unavailable on an actual node are filtered using temporary nodes in a
disposable tree; these results are cached for subsequent searches.

Search preferences, operation symbols, Mix Color/Mix RGB aliases, deprecated
node display, and usage sorting remain available. Usage tallies are saved in
Blender's user configuration folder under `node_tabber/tally_cache`. Existing
installation-folder tallies are read until superseded by a user-config tally.

External add-on nodes registered through `nodeitems_utils` remain supported.
Asset-library node groups that have not been loaded into the file continue to
use Blender's native Add/asset menus; this add-on does not enumerate remote or
unloaded asset libraries. Built-in node coverage does not imply coverage of
every third-party node implementation.

## Validation

Run from this directory (substitute your Blender executable):

```powershell
& blender.exe --background --factory-startup --python-exit-code 1 --python tests/blender_compat.py
```

The test registers and unregisters the add-on, creates every generated search
entry in eight editor contexts, checks all four editors with subtypes disabled,
and independently checks native node coverage against the running Blender's
registry. It also checks zone pairing, selection, group recursion, group width,
and cleanup after failed zone creation. Results are saved in
`tests/compat-report.json`.

These are real Blender background integration tests. Interactive popup drawing,
mouse-driven placement, and undo behavior still require an interactive check.
The retained 5.0 catalogs are a fallback; this update's exhaustive validation was
performed on 5.2.3.

To regenerate the version-specific catalogs using another installed Blender:

```powershell
& blender.exe --background --factory-startup --python-exit-code 1 --python tools/generate_catalog.py
```

The generator preserves curated aliases and filters from the 5.0 baseline,
removes unavailable node types, and discovers additions through actual node
creation in temporary node trees.
